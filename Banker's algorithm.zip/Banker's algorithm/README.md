# OS-Simulator

This is an application built using  JS, HTML and CSS which simulates the Operating Systems Concepts.
The password for the login screen is "cldadr".



